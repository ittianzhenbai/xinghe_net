<template>
    <div>
        党建党规
    </div>
</template>
<script>
export default {
    data(){

    },
    created(){
    },
    mounted(){},
    methods:{}
}
</script>
<style lang="stylus" scoped>

</style>