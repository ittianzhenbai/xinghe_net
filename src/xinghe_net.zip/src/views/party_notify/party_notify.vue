<template>
    <div>
        文件通知
    </div>
</template>
<script>
export default {
    data(){

    },
    created(){
    },
    mounted(){},
    methods:{}
}
</script>
<style lang="stylus" scoped>

</style>