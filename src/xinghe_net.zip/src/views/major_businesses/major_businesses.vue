<template>
    <div>
        我是主营业务,跟着字体变化一波吧
    </div>
</template>
<script>
import control_fontsize from  '../../common/js/control.js'
export default {
    data(){
        return{

        }
    },
    mounted(){
        control_fontsize()
    }
}
</script>