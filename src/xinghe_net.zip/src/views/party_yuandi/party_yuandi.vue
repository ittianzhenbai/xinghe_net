<template>
    <div>
        学习园地
    </div>
</template>
<script>
export default {
    data(){

    },
    created(){
    },
    mounted(){},
    methods:{}
}
</script>
<style lang="stylus" scoped>

</style>