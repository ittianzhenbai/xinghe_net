<template>
    <div class="container-fluid main">
        <div class="row banner">
            <el-carousel class="swiper" 
                :interval="3000" 
                arrow="always"
                indicator-position="none"
                loop:true
            >
                <el-carousel-item class="swiper_item" v-for="item in 3" :key="item">
                    <img src="../../assets/1.png" alt="">
                </el-carousel-item>
            </el-carousel>
        </div>
        <div class="container-fluid content">
            <div class="row yewu">
                <ul class="major_businesses">
                    <li v-for="item in 5" :key="item">
                        <img src="../../assets/1.png" alt="">
                        <div class="active">
                            <span>标题</span>
                            <p class="intro">
                                这是一段文字，这是一段文字，这是一段文字，这是一段文字
                            </p>
                            <div>...</div>
                        </div>
                    </li>
                </ul>
            </div>
            <div class="row near_xinghe">
                <div class="company_intro col-12 col-md-12">
                    <span>走进兴合</span>
                    <p>浙江省兴合集团有限责任公司是中国500强企业，浙江省重点流通企业和供销系统为农服务龙头企业，主要负责运行管理浙江省供销社本级经营性资产。</p>
                </div>
            </div>
            <div class="row rongyu">
                <ul class="col-md-10">
                    <li v-for="item in 5" :key="item" class="col-12 col-sm-2 col-md-2">
                        <span>1200</span>
                        <p>1992年公司经省政府批准设立，已有28个年头</p>
                    </li>
                </ul>
                <div class="col-12 col-md-12">
                    <span class="detail">详情</span>
                </div>
            </div>
        </div>
        <div class="row news_center">
            <div class="title col-12 col-md-12">新闻中心</div>
            <ul class="options col-12 col-md-12">
                <li 
                    class="item col-6 col-md-6"
                    @click="jump_router('1')"
                    :class="{ active: content_show == 1 }"
                >
                    集团新闻
                </li>
                <li 
                    class="item col-6 col-md-6"
                    @click="jump_router('2')"
                    :class="{ active: content_show == 2 }"
                >
                    成员企业新闻
                </li>
            </ul>
            <!-- <div class="col-12 col-md-12 row">
               <router-view></router-view>
            </div> -->
        </div>
    </div>
</template>
<script>
import { mapMutations } from "vuex";
export default {
    data(){
        return{
            content_show:"1"
        }
    },
    methods:{
        ...mapMutations(["setActiveIndex"]),
        jump_router(item){
            this.content_show = item
            if(item == "1"){
                this.$router.push({path:"/news_group"})
                this.setActiveIndex("3-1")
            }
            if(item == "2"){
                this.$router.push({path:"/news_menber"})
                this.setActiveIndex("3-2")
            }
        }
    }
}
</script>
<style lang="stylus" scoped>
@keyframes myfirst
{
    0% {
        background rgba(255,0,0,0)
        opacity 0
    }
    25%{
        background rgba(41,50,57,.2)
    }
    50%{
        background rgba(41,50,57,.3)
    }
    75%{
        background rgba(41,50,57,.5)
    }
    100% {
        visibility visible
        background rgba(41,50,57,.6)
        opacity 1
    }
}
.main
    padding 0
    .banner
        padding 0
        width 100%
        margin 0
        .swiper
            width 100%
            .swiper_item
                line-height 3rem
                &>img
                    width 100%
                    height 300px
    .content
        width 100%
        margin 0
        padding 0
        .yewu
            margin 0
            .major_businesses
                width 30.2rem 
                margin 0 auto
                height 9rem
                position relative
                bottom 4.5rem
                z-index 9
                &>li
                    height 9rem
                    width 6rem
                    border 1px solid yellow
                    display inline-block
                    position relative
                    @media screen and (max-width:768px)
                        display none
                    img
                        width 100%
                        height 100%
                    .active
                        width 100%
                        height 100%
                        visibility hidden
                        position absolute
                        top 0
                        padding 1rem 0
                        span
                            line-height 1rem
                        div
                            border 1px solid #000000
                            width 30px
                            height 20px
                            color #FFFFFF
                            margin 0 auto
                            line-height 10px
                        .intro
                            font-size 0.2rem
                            display -webkit-box
                            -webkit-box-orient vertical
                            -webkit-line-clamp 3  //需要显示时文本行数
                            overflow hidden
                &>li:hover
                    .active
                        width 100%
                        animation-name myfirst
                        animation-duration 1s
                        animation-iteration-count 1
                        animation-fill-mode forwards
        .near_xinghe
            margin 0
            .company_intro
                margin 0 auto
                padding 0 0 
                width 100%
                span
                    text-align cneter
                    font-size 2rem
                p
                    width 50%
                    @media screen and (max-width:768px)
                        width 90%
                    margin 0 auto
        .rongyu
            width 100%
            margin-top 30px
            margin-right 0
            margin-left 0
            padding 0
            ul
                margin 0 auto
                &>li
                    display inline-block
                    span
                        font-size 3rem
                        color #1A639D
                        font-weight 800
                    p
                        line-height 1.5rem
                        font-size 0.8rem
            .detail
                margin 0 auto
                border 1px solid #1A639D
                border-radius 10%
                display inline-block
                width 3rem
        .news_center
            background #F4F4F4
            margin-top 2rem
            margin-left 0
            margin-right 0
            .title
                font-size 3rem
                font-weight 800
                margin 0 auto
            .options
                margin-bottom 1rem
                padding 0 0
                margin 0 0
                width 100%
                &>li
                    display inline-block
                    cursor pointer
                    font-size 2rem
                    @media screen and (max-width:768px)
                        font-size 1.5rem
                    color #000000
                    text-align center
                    &.active
                        border-bottom 2px solid #79A2C5
                        color #79A2C5 
            
</style>