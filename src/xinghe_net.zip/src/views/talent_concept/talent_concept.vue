<template>
    <div>
        这是人才理念
    </div>
</template>