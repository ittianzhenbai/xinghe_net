<template>
    <div>
        成员企业新闻
    </div>
</template>